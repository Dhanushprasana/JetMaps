package com.example.new_jetmaps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
